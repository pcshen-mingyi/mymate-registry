---
name: mymate-setup
description: 當使用者說「幫我裝 MYmate」「幫我把專案接進 Claude」「設定 MYmate」時，陪他從零完成安裝到第一份專案摘要。使用者是非技術者。
---

# MYmate 安裝陪跑

你要陪一位**非技術使用者**把 MYmate 裝起來，一路到 Claude 能讀他的專案。全程用他聽得懂的話。

## 鐵律（每一步都遵守）
1. **先講、再做**：每個步驟開始前，先用一句話說「接下來會發生什麼、你會看到什麼」。
2. **一次一步**：不要一次丟三個指令。等這步成功再下一步。
3. **錯誤給下一步，不給術語**：出錯時說「我們這樣解決」，不要貼 traceback 或英文錯誤。
4. **共用權限一定他本人做**：Google 登入、把資料夾/試算表「共用」給服務帳戶——**你只給他要貼的 email 和位置，按鈕他自己按**。這是隱私紅線。
5. **慢不等於壞**：同步大資料夾可能數分鐘，主動說「這是正常的，我在盯進度」。

---

## 步驟 0：環境檢測（不動任何東西）
執行 `bash <skill>/scripts/preflight.sh`，讀 `KEY=VALUE`。
- `mymate_found` 有值且 `mymate_version` 夠新 → 已裝好，跳到步驟 2。
- 否則 → 步驟 1 安裝。
先跟使用者說：「我先看看你電腦上有沒有裝過，不會改任何東西。」

## 步驟 1：安裝
跟他說：「我幫你裝一個小工具，大概一兩分鐘，會看到一些安裝訊息，正常的。」
- 執行 repo 的 `bash install.sh`（會偵測 Python、建環境、裝好、建立捷徑）。
- 若 `path_has_local=no`：跟他說「我幫你設定好讓它隨時能用」，並給**那一行** PATH 指令請他貼到終端機執行（或你代跑）。
- 驗證：`mymate --version` 有輸出版本 → 跟他說「裝好了 ✅」。
- 失敗處理：
  - 找不到 Python 3.10+ → 「你的電腦需要先裝一個新版 Python，我帶你裝」→ 引導 `brew install python@3.12`（沒有 brew 就給 python.org 下載頁）。

## 步驟 2：開設定介面 + 對接
跟他說：「我開一個網頁面板，等一下設定都在上面點。」
- 執行 `mymate agent-info` 看 `ui.running`。
- 若沒在跑：背景執行 `mymate ui`（或 `mymate ui --no-browser`），它會把連線資訊寫到 `~/.mymate/ui_session.json`。
- 讀 `~/.mymate/ui_session.json` 取得 `base_url` 與 `token`（同一使用者帳號才讀得到，這是設計）。
- 之後你所有操作都對 `base_url` 打 API，帶 header `X-Mymate-Token: <token>`。使用者不需要看到 token。

## 步驟 3：註冊他的專案資料夾
問他：「你的專案資料夾在哪？（例如『文件』裡的某個資料夾）」拿到路徑後：
- `POST /api/workspaces {"path": "<資料夾>"}`。
- 跟他說：「我只會在裡面放一個小小的設定檔，你原本的檔案一個都不會動。」

## 步驟 4：Google 憑證（GCP）
這是唯一需要他到 Google 網站的部分。跟他說：「這一步是讓 MYmate 有權限『唯讀』你指定的 Google 資料，我一步步帶你。」
- **你有瀏覽器工具**：可代他點 GCP Console 的建立專案、啟用 Drive/Sheets API、建立服務帳戶、下載金鑰（依 `docs/gdrive_setup.md` 的固定步驟）。**但下載金鑰後**：
- **共用（他本人做，紅線）**：
  1. 把服務帳戶 email 複製出來，原封不動貼給他，說：「請複製這一段。」
  2. 「打開你要同步的 Google 資料夾 → 右上『共用』→ 貼上這段 email → 權限選『檢視者』→ 傳送。」
  3. 一次只帶一個共用動作，等他說「好了」再繼續。
- 金鑰檔路徑先記著（下一步填進去，MYmate 會自動收管到安全位置並設權限）。

## 步驟 5：設定資料源（含範圍確認）
跟他說：「我把你的 Google 資料接上來，接之前先看一眼有哪些資料夾，太雜的可以不收。」
- `POST /api/sources/test`（帶 config）確認設定沒問題。
- **預掃描**：`POST /api/sources/prescan` → 把「第一層資料夾 + 檔數」用中文唸給他聽：「我看到這幾個資料夾：A（30 檔）、B（500 檔的營運數據）…要不要略過哪些？」
  - 主動建議：明顯是日誌/營運數據的大資料夾建議排除，理由用白話：「這些數字檔對『專案摘要』幫助不大，收進來會變慢也變雜。」
- 帶著他的選擇 `POST /api/sources {config 含 exclude 與 project 歸屬}`。憑證會自動收管、原檔留著。

## 步驟 6：首次同步（盯進度）
跟他說：「開始把資料抓下來，這步可能要幾分鐘，我會一直看進度，不用擔心。」
- `POST /api/sync` → 拿 `job_id`。
- 每隔約 2 秒 `GET /api/sync/progress?job_id=...`：
  - `status=running`：把 `files_done/total` 與 `item` 翻成「已處理 12/200，目前：某某文件」。
  - `heartbeat_age` 變大（>90 秒沒動）→ 跟他說「這個檔比較大，還在跑；如果你想停我可以取消重試」，必要時 `POST /api/sync/cancel`。
  - `status=failed`：**不要貼英文**。看 `error` 用白話轉述 + 給下一步（多半是憑證或共用沒按到 → 回步驟 4 的共用）。
  - `status=done`：跟他說「抓完了 ✅」。

## 步驟 7：產出摘要 + 驗證
- `POST /api/index`。
- 驗證：確認 `_datalake/index.md` 產生、CLAUDE.md 有 `mymate:begin` 區塊。
- 跟他說：「好了！你的專案摘要做好了，Claude 現在讀得到。」

## 步驟 8：教他第一句話
用他的專案名舉例，教他可以問 Claude：
- 「我的專案現在卡在哪？」
- 「哪些專案卡還沒填？」
- 「這週動了哪些檔案？」
說：「以後你在 Claude 打開這個資料夾，直接問這些就行。」

---

## 收尾檢查（你自己確認，不用唸給他）
- [ ] `mymate --version` 可用
- [ ] workspace 已註冊、資料源已存（憑證在 `~/.mymate/credentials/`，非 Downloads）
- [ ] 首次 sync 完成、index 產出、CLAUDE.md 已注入
- [ ] 全程未替他按「共用」；未把 token 或金鑰內容顯示給他
