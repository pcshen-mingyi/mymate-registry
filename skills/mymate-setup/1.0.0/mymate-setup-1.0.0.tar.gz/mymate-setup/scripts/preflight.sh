#!/usr/bin/env bash
# MYmate 安裝前環境檢測（給 SKILL.md 呼叫）。輸出機讀 KEY=VALUE。
# 不改動任何東西，只偵測。

emit() { echo "$1=$2"; }

# 是否已安裝 mymate（PATH 或常見捷徑）
if command -v mymate >/dev/null 2>&1; then
  emit mymate_found "$(command -v mymate)"
  emit mymate_version "$(mymate --version 2>/dev/null | awk '{print $2}')"
elif [ -x "$HOME/.local/bin/mymate" ]; then
  emit mymate_found "$HOME/.local/bin/mymate"
  emit mymate_version "$("$HOME/.local/bin/mymate" --version 2>/dev/null | awk '{print $2}')"
else
  emit mymate_found ""
  emit mymate_version ""
fi

# 合適的 Python（>=3.10）
py=""
for c in python3.13 python3.12 python3.11 python3.10 python3; do
  if command -v "$c" >/dev/null 2>&1 && \
     "$c" -c 'import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)' 2>/dev/null; then
    py="$c"; break
  fi
done
emit python_ok "$([ -n "$py" ] && echo yes || echo no)"
emit python_bin "$py"

# uv（airbyte 引擎用；缺不擋 native）
emit uv_found "$(command -v uv 2>/dev/null || echo '')"

# PATH 是否含 ~/.local/bin
case ":$PATH:" in *":$HOME/.local/bin:"*) emit path_has_local yes ;; *) emit path_has_local no ;; esac

# UI session（是否已在跑）
[ -f "$HOME/.mymate/ui_session.json" ] && emit ui_session yes || emit ui_session no
