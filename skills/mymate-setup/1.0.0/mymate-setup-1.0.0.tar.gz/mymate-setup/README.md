# mymate-setup skill（type: operation）

給 **Claude**（Cowork / Claude Code）用的安裝陪跑腳本，讓非技術使用者對 Claude 說
「幫我裝 MYmate」即完成安裝→接資料源→首次 datalake 的全程。

## 這不是 domain skill
- 沒有 `build`/`render` entrypoint；核心是 `SKILL.md`（陪跑腳本）＋ `scripts/preflight.sh`（環境檢測）。
- 由 registry 分發（含 sha256 完整性），但**執行者是 Claude**，不是 mymate client 的 index 引擎。

## 安裝進 Claude（MVP4 接受此步驟為手動）
1. 從 registry 取得本 skill 包（`mymate skill install mymate-setup` 會下載並驗證 sha256，落地到 `~/.mymate/skills/mymate-setup/<version>/`）。
2. 於 **Cowork → Settings → 匯入 skill**，指向該資料夾的 `SKILL.md`（或依 Cowork 當前匯入方式）。
3. 之後使用者對 Claude 說「幫我裝 MYmate」即觸發本 skill。

> 未來自動化匯入為 MVP5+ 議題；MVP4 明確接受手動匯入。

## 相依
- 需要 repo 的 `install.sh` 與 client（`mymate` CLI、`mymate ui`、`mymate agent-info`）。
- Google Drive 走 native 引擎；Google Sheets 走 airbyte 引擎（首次會用 uv 建隔離環境）。
