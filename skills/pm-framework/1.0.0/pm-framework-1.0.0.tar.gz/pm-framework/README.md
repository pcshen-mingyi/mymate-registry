# pm-framework skill

MYmate 的第一個領域 skill：把「專管系統」慣例（狀態資料夾 + `[階段]` 專案命名 + `_專案卡.md`）
解析成 datalake。行為由 MVP1 `indexer.py` 重構而來，以回歸測試鎖住。

## 檔案

| 檔案 | 責任 |
|---|---|
| `skill.yaml` | id/name/version/min_client_version/entrypoint |
| `schema.yaml` | 領域常數（狀態映射、階段、代號、警示參數…），改這裡即改行為 |
| `extract.py` | `build(workspace_path, external_dir, schema) -> dict` |
| `render_index.py` | `render(data, schema) -> str`（index.md 全文） |
| `external_map.py` | Drive 資料夾 → 專案 映射（M4） |
| `claude_section.md` | 注入 CLAUDE.md 標記區塊的模板 |

## 慣例

- 狀態資料夾：`01_進行中`…`06_被諮詢`
- 專案資料夾：`[階段] 名稱`，可選代號前綴（僅 `schema.yaml::known_codes` 列出者）
- 專案卡：`_專案卡.md`，欄位 `**階段**` `**狀態**` `**歸屬目的**` `**更新日**`，章節 `## 現況` `## 下一步` `## 卡點` `## 里程碑`

skill 不碰網路、不寫 datalake 以外的路徑（規格 §2）。
