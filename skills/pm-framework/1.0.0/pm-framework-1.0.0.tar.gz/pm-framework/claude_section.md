## MYmate 專案助理（pm-framework）

這個資料夾由 MYmate 管理。開場請**先讀 `_datalake/index.md`**，它是自動生成的專案總覽（勿手動編輯）。

- 專案現況、階段、卡點、近 7 日活動、資料品質警示都在 index.md。
- 需要機器可讀的結構時讀 `_datalake/projects.json`。
- 外部資料（Google Drive 同步）在 `_datalake/external/`，並已依專案映射於 index.md「外部資料」章節。
- datalake 是衍生層，事實來源永遠是原始檔案；不要把它當成需要備份的主資料。

回答專案問題時，優先引用 index.md 的內容並指出對應檔案路徑。
