"""pm-framework 萃取邏輯（entrypoint: build）。

行為 = MVP1 `_mymate_client/indexer.py` 的 parse_folder_name / norm_stage /
parse_card / scan_files / check_warnings / build，逐項搬移並以 schema 參數化常數。
以回歸測試鎖住（AC-5）。

介面契約（規格 §6）：
    build(workspace_path: str, external_dir: str | None, schema: dict) -> dict
回傳沿用 MVP1 projects.json 結構，另加 external 欄位（M4 填入）。
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta
from pathlib import Path

from external_map import map_external  # 同 skill 目錄的模組


# --- schema 存取小工具 ------------------------------------------------------

def _s(schema: dict) -> dict:
    return schema or {}


def parse_folder_name(name: str, known_codes: set[str]) -> tuple[str | None, str | None, str]:
    m = re.match(r"^\[(?P<stage>[^\]]+)\]\s*(?P<rest>.+)$", name)
    stage_tag, rest = (
        (m.group("stage").strip(), m.group("rest").strip()) if m else (None, name)
    )
    code = None
    cm = re.match(r"^([A-Za-z]{2,10})-", rest)
    if cm and cm.group(1) in known_codes:
        code = cm.group(1)
    return stage_tag, code, rest


def norm_stage(s: str | None, stages: list[str]) -> str:
    """「PSF（Problem-Solution Fit）」→「PSF」"""
    if not s:
        return ""
    for st in stages:
        if s.startswith(st):
            return st
    return s.strip()


def parse_card(path: Path) -> dict:
    """解析 _專案卡.md → dict。容忍範本未填的欄位。"""
    try:
        text = path.read_text(encoding="utf-8")
    except Exception as e:  # noqa: BLE001 - 行為沿用 MVP1
        return {"error": str(e)}
    card: dict = {}
    for key in ("階段", "狀態", "歸屬目的", "更新日"):
        m = re.search(r"\*\*%s\*\*[：:]\s*(.*)" % key, text)
        if m:
            val = m.group(1).strip()
            # 範本殘留（列出所有選項）視為未填
            if val.count("/") >= 2 and key in ("階段", "狀態"):
                val = ""
            card[key] = val
    sections: dict[str, str] = {}
    parts = re.split(r"^##\s+", text, flags=re.M)
    for p in parts[1:]:
        lines = p.splitlines()
        title = lines[0].strip()
        body = "\n".join(lines[1:]).strip()
        sections[title] = body
    for k in ("現況", "下一步", "卡點", "里程碑"):
        card[k] = sections.get(k, "").strip()
    done = len(re.findall(r"- \[x\]", card.get("里程碑", ""), re.I))
    todo = len(re.findall(r"- \[ \]", card.get("里程碑", "")))
    card["里程碑進度"] = {"done": done, "total": done + todo}
    return card


def scan_files(proj_dir: Path, card_name: str) -> dict:
    """檔案清單：總數、最新活動、近檔 top5（排除封存與隱藏檔）。"""
    files: list[tuple[float, str]] = []
    n_archived = 0
    for root, dirs, names in os.walk(proj_dir):
        if "99_封存" in Path(root).parts:
            n_archived += len([n for n in names if not n.startswith(".")])
            continue
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for n in names:
            if n.startswith(".") or n == card_name:
                continue
            p = Path(root) / n
            try:
                mt = p.stat().st_mtime
            except OSError:
                continue
            files.append((mt, str(p.relative_to(proj_dir))))
    files.sort(reverse=True)
    return {
        "file_count": len(files),
        "archived_count": n_archived,
        "latest_mtime": datetime.fromtimestamp(files[0][0]).strftime("%Y-%m-%d %H:%M")
        if files
        else None,
        "recent_files": [
            {"path": f, "mtime": datetime.fromtimestamp(mt).strftime("%Y-%m-%d")}
            for mt, f in files[:5]
        ],
    }


def check_warnings(proj: dict, schema: dict) -> list[str]:
    sc = _s(schema)
    stages = sc.get("stages", [])
    status_values = list(sc.get("status_map", {}).values())
    stale_days = int(sc.get("card_stale_days", 7))

    w: list[str] = []
    card = proj.get("card")
    if card is None:
        w.append("缺 _專案卡.md")
        return w
    if card.get("error"):
        w.append("專案卡讀取失敗：" + card["error"])
        return w
    stage_tag, cs = proj.get("stage_tag"), norm_stage(card.get("階段", ""), stages)
    if stage_tag and cs and stage_tag != cs:
        w.append(f"資料夾標籤 [{stage_tag}] 與專案卡階段「{cs}」不一致")
    fs, ds = proj.get("status"), card.get("狀態", "")
    if ds and fs in status_values and fs not in ("BAU", "被諮詢") and ds != fs:
        w.append(f"所在資料夾狀態「{fs}」與專案卡狀態「{ds}」不一致")
    upd = card.get("更新日", "")
    latest = proj["files"]["latest_mtime"]
    if upd and latest:
        try:
            d_upd = datetime.strptime(upd, "%Y-%m-%d")
            d_act = datetime.strptime(latest[:10], "%Y-%m-%d")
            if (d_act - d_upd).days > stale_days:
                w.append(f"專案卡更新日 {upd} 落後最新檔案活動 {latest[:10]}，可能過期")
        except ValueError:
            w.append(f"更新日格式異常：{upd}")
    if not card.get("現況") and not card.get("下一步"):
        w.append("專案卡「現況／下一步」為空，待補")
    return w


def build(workspace_path: str, external_dir: str | None, schema: dict) -> dict:
    sc = _s(schema)
    status_map: dict = sc.get("status_map", {})
    status_order: list[str] = sc.get("status_order", [])
    stages: list[str] = sc.get("stages", [])
    known_codes = set(sc.get("known_codes", []))
    card_name: str = sc.get("card_name", "_專案卡.md")
    kb_dirname: str = sc.get("knowledge_base_dir", "00_知識庫")
    recent_days = int(sc.get("recent_days", 7))

    root = Path(workspace_path).resolve()
    projects: list[dict] = []
    for status_dir, status in status_map.items():
        base = root / status_dir
        if not base.is_dir():
            continue
        for entry in sorted(base.iterdir()):
            if (
                not entry.is_dir()
                or entry.name.startswith(".")
                or entry.name.startswith("_")
            ):
                continue
            stage_tag, code, name = parse_folder_name(entry.name, known_codes)
            card_path = entry / card_name
            proj = {
                "name": name,
                "code": code,
                "stage_tag": stage_tag,
                "status": status,
                "path": str(entry.relative_to(root)),
                "card": parse_card(card_path) if card_path.exists() else None,
                "files": scan_files(entry, card_name),
                "external": [],  # M4 映射填入
            }
            proj["stage"] = norm_stage((proj["card"] or {}).get("階段"), stages) or stage_tag or ""
            proj["warnings"] = check_warnings(proj, sc)
            projects.append(proj)

    projects.sort(key=lambda p: (status_order.index(p["status"]), p["name"]))

    # 知識庫清單
    kb: list[dict] = []
    kb_dir = root / kb_dirname
    if kb_dir.is_dir():
        for r, dirs, names in os.walk(kb_dir):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for n in sorted(names):
                if n.startswith("."):
                    continue
                p = Path(r) / n
                kb.append(
                    {
                        "path": str(p.relative_to(root)),
                        "mtime": datetime.fromtimestamp(p.stat().st_mtime).strftime(
                            "%Y-%m-%d"
                        ),
                    }
                )

    # 近 N 日活動（跨專案）
    cutoff = datetime.now() - timedelta(days=recent_days)
    recent: list[dict] = []
    for p in projects:
        for f in p["files"]["recent_files"]:
            if datetime.strptime(f["mtime"], "%Y-%m-%d") >= cutoff:
                recent.append({"project": p["name"], **f})
    recent.sort(key=lambda x: x["mtime"], reverse=True)

    # 外部資料映射（M4；無 external_dir 時回傳空）
    unmapped = map_external(projects, external_dir, sc)

    return {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "root": str(root),
        "projects": projects,
        "knowledge_base": kb,
        "recent_activity": recent,
        # 頂層 external[]（§6）：對不上專案的外部資料夾（unmapped）。
        # 對得上的已就地掛進各 project['external']。
        "external": unmapped,
    }
