"""外部資料（Drive）→ 專案映射（規格 §8）。

M2：介面就位，無 external_dir 時回傳空 unmapped、不動 projects。
M4：實作正規化比對（去 [階段]、空白、大小寫），對上的掛進 project['external']，
    對不上的列入 _unmapped。
"""

from __future__ import annotations

import re
from pathlib import Path


def normalize_name(name: str) -> str:
    """去 [階段] 標籤、去空白、轉小寫，供專案名／代號比對。"""
    n = re.sub(r"^\[[^\]]*\]", "", name)  # 去開頭 [階段]
    n = re.sub(r"\s+", "", n)
    return n.strip().lower()


def map_external(projects: list[dict], external_dir: str | None, schema: dict) -> list[dict]:
    """把 external_dir 下的 Drive 第一層資料夾映射到 projects。

    回傳 unmapped 清單（對不上的資料夾）。就地修改 projects 的 'external'。
    M2 佔位：external_dir 為 None 或不存在時回傳 []。
    """
    if not external_dir:
        return []
    base = Path(external_dir) / "gdrive"
    if not base.is_dir():
        return []

    # 專案正規化索引：名稱與代號都可對上。
    index: dict[str, dict] = {}
    for p in projects:
        index[normalize_name(p["name"])] = p
        if p.get("code"):
            index[normalize_name(p["code"])] = p

    unmapped: list[dict] = []
    for entry in sorted(base.iterdir()):
        if not entry.is_dir() or entry.name.startswith("."):
            continue
        docs = [
            str(f.relative_to(base))
            for f in sorted(entry.rglob("*"))
            if f.is_file() and not f.name.startswith(".")
        ]
        target = index.get(normalize_name(entry.name))
        if target is not None:
            target["external"].extend(docs)
        else:
            unmapped.append({"folder": entry.name, "docs": docs})
    return unmapped
