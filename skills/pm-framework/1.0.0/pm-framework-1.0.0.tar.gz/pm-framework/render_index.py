"""pm-framework 渲染邏輯（entrypoint: render）。

行為 = MVP1 indexer.py 的 render_md，另加（規格 §9）：
- header 印 client 版本＋skill 版本＋生成時間
- 新增「外部資料」章節（各專案 Drive 文件清單與 _unmapped）
資訊集合為 MVP1 之超集（AC-5）。
"""

from __future__ import annotations


def render(data: dict, schema: dict) -> str:
    recent_days = int((schema or {}).get("recent_days", 7))
    versions = data.get("versions", {})
    client_v = versions.get("client", "?")
    skill_v = versions.get("skill", "?")

    L: list[str] = []
    L.append("# 專案 Datalake（自動生成，勿手編）")
    L.append("")
    L.append(
        f"> 生成時間：{data['generated_at']}"
        f"｜client v{client_v}｜skill pm-framework v{skill_v}"
    )
    L.append("")
    L.append("## 專案總覽")
    L.append("")
    L.append("| 專案 | 代號 | 階段 | 狀態 | 卡更新日 | 最新檔案活動 | 檔案數 | 警示 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for p in data["projects"]:
        c = p["card"] or {}
        L.append(
            "| {} | {} | {} | {} | {} | {} | {} | {} |".format(
                p["name"],
                p["code"] or "—",
                p["stage"] or "—",
                p["status"],
                c.get("更新日") or "—",
                (p["files"]["latest_mtime"] or "—")[:10],
                p["files"]["file_count"],
                "⚠️" + str(len(p["warnings"])) if p["warnings"] else "",
            )
        )
    L.append("")

    L.append(f"## 近 {recent_days} 日活動")
    L.append("")
    if data["recent_activity"]:
        for a in data["recent_activity"][:15]:
            L.append(f"- {a['mtime']}｜{a['project']}｜`{a['path']}`")
    else:
        L.append("（無）")
    L.append("")

    L.append("## 各專案詳情")
    L.append("")
    for p in data["projects"]:
        c = p["card"] or {}
        L.append(f"### {p['name']}（{p['status']}｜{p['stage'] or '—'}）")
        L.append("")
        L.append(f"- 位置：`{p['path']}`")
        if c.get("歸屬目的"):
            L.append(f"- 歸屬目的：{c['歸屬目的']}")
        ms = c.get("里程碑進度") or {}
        if ms.get("total"):
            L.append(f"- 里程碑：{ms['done']}/{ms['total']}")
        for key in ("現況", "下一步", "卡點"):
            v = (c.get(key) or "").strip()
            if v:
                first = " ".join(v.splitlines())
                L.append(f"- {key}：{first[:200]}")
        if p["files"]["recent_files"]:
            f0 = p["files"]["recent_files"][0]
            L.append(f"- 最近檔案：`{f0['path']}`（{f0['mtime']}）")
        for w in p["warnings"]:
            L.append(f"- ⚠️ {w}")
        L.append("")

    # 外部資料（規格 §9 新增）
    L.append("## 外部資料")
    L.append("")
    any_ext = False
    for p in data["projects"]:
        docs = p.get("external") or []
        if docs:
            any_ext = True
            L.append(f"### {p['name']}")
            for d in docs:
                L.append(f"- `{d}`")
            L.append("")
    unmapped = (data.get("external") or {}).get("unmapped") or []
    if unmapped:
        any_ext = True
        L.append("### 未對應到專案（_unmapped）")
        for u in unmapped:
            L.append(f"- 資料夾 `{u['folder']}`（{len(u.get('docs', []))} 份文件）")
        L.append("")
    if not any_ext:
        L.append("（無外部資料來源）")
        L.append("")

    L.append("## 資料品質警示彙總")
    L.append("")
    any_w = False
    for p in data["projects"]:
        for w in p["warnings"]:
            L.append(f"- {p['name']}：{w}")
            any_w = True
    if not any_w:
        L.append("（無）")
    L.append("")

    L.append("## 知識庫")
    L.append("")
    for k in data["knowledge_base"]:
        L.append(f"- `{k['path']}`（{k['mtime']}）")
    L.append("")
    return "\n".join(L)
