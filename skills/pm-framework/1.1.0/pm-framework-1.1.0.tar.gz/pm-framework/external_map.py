"""外部資料（Drive/Sheets）→ 專案映射（規格 §8 + MVP4 回饋 #4）。

優先序：
1. **source 明確歸屬**（`external/_sources.json` 的 {landing: 專案名}）→ 該源全部檔案掛該專案。
2. 否則（native gdrive 無指定）→ 依第一層資料夾名正規化比對專案名／代號。
對不上者列入 _unmapped。就地填入各 project['external']（相對 external 的路徑清單）。
"""

from __future__ import annotations

import json
import re
from pathlib import Path


def normalize_name(name: str) -> str:
    """去 [階段] 標籤、去空白、轉小寫，供專案名／代號比對。"""
    n = re.sub(r"^\[[^\]]*\]", "", name)
    n = re.sub(r"\s+", "", n)
    return n.strip().lower()


def _files_under(d: Path, external_dir: Path) -> list[str]:
    return [
        str(f.relative_to(external_dir))
        for f in sorted(d.rglob("*"))
        if f.is_file() and not f.name.startswith(".")
    ]


def map_external(projects: list[dict], external_dir: str | None, schema: dict) -> list[dict]:
    """映射 external 下各來源到專案。回傳 unmapped；就地修改 projects 的 'external'。"""
    if not external_dir:
        return []
    base = Path(external_dir)
    if not base.is_dir():
        return []

    # 專案查找：正規化名稱／代號，以及原名精確查找。
    index: dict[str, dict] = {}
    for p in projects:
        index[normalize_name(p["name"])] = p
        if p.get("code"):
            index[normalize_name(p["code"])] = p
    by_name = {p["name"]: p for p in projects}

    # source→專案 覆寫（回饋 #4）。
    overrides: dict[str, str] = {}
    manifest = base / "_sources.json"
    if manifest.exists():
        try:
            overrides = json.loads(manifest.read_text(encoding="utf-8")).get("source_projects", {})
        except (json.JSONDecodeError, OSError):
            overrides = {}

    def resolve(proj_name: str):
        return by_name.get(proj_name) or index.get(normalize_name(proj_name))

    unmapped: list[dict] = []
    for landing in sorted(base.iterdir()):
        if not landing.is_dir() or landing.name.startswith((".", "_")):
            continue

        # 1) source 明確歸屬 → 整個 landing 的檔案掛該專案。
        if landing.name in overrides:
            docs = _files_under(landing, base)
            target = resolve(overrides[landing.name])
            if target is not None:
                target["external"].extend(docs)
            else:
                unmapped.append({
                    "folder": landing.name, "docs": docs,
                    "note": f"指定歸屬專案「{overrides[landing.name]}」不存在",
                })
            continue

        # 2) native gdrive 無指定 → 第一層子資料夾名比對。
        if landing.name == "gdrive":
            for sub in sorted(landing.iterdir()):
                if not sub.is_dir() or sub.name.startswith("."):
                    continue
                docs = _files_under(sub, base)
                target = index.get(normalize_name(sub.name))
                if target is not None:
                    target["external"].extend(docs)
                else:
                    unmapped.append({"folder": sub.name, "docs": docs})
        else:
            # 其他來源（如 airbyte）無指定歸屬 → unmapped。
            unmapped.append({"folder": landing.name, "docs": _files_under(landing, base)})

    return unmapped
